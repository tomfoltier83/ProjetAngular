export class Coin {
  constructor(public symbol: string, public image: string, public quantityNewToken: number, public current_price: number) {}
  price_change_percentage_24h: number;
  total_volume: number;
  id: string;
}

