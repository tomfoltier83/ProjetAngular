import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { Coin } from '../models/Coin.models';


@Injectable({
  providedIn: 'root'
})
export class CryptoService implements OnInit {

  tokenSubject = new Subject<any[]>();

  private tokens = <any[]>([]);

  coins: Coin[] = [];

  constructor(private httpClient: HttpClient) { }

  ngOnInit(): void {
    this.httpClient
    .get<Coin[]>(
      'https://api.coingecko.com/api/v3/coins/markets?vs_currency=eur&order=market_cap_desc&per_page=100&page=1&sparkline=false'
    )
    .subscribe(
      res => {
        console.log(res);
        this.coins = res;
      },
      err => console.log(err)
    );
  }

  emitTokenSubject() {
    this.tokenSubject.next(this.tokens.slice());
  }

  addCrypto(symbol: string, quantityNewToken: number) {
    const newToken ={
      symbol: '',
      quantityNewToken: 0
    };
    newToken.symbol = symbol;
    newToken.quantityNewToken = quantityNewToken;


    this.tokens.push(newToken);
    this.emitTokenSubject();
  }
  saveTokensToServer() {
    this.httpClient
      .put('https://crypto-wallet-f2e92-default-rtdb.europe-west1.firebasedatabase.app/ownToken.json', this.tokens)
      .subscribe(
        () => {
          console.log('Enregistrement terminé !');
        },
        (error) => {
          console.log('Erreur de sauvegarde !' + error);
        }
      );
  }

  getTokensFromServeur() {
    this.httpClient
      .get<any[]>('https://crypto-wallet-f2e92-default-rtdb.europe-west1.firebasedatabase.app/ownToken.json')
      .subscribe(
        (response) => {
          this.tokens = response;
          this.emitTokenSubject();
        },
        (error) => {
          console.log('Erreur de chargement !' + error);
        }
      );
  }

  walletLoad() {
    return new Promise(
      (resolve, reject) => {
          setTimeout(
              () => {
                this.getTokensFromServeur();;
                  resolve(true);
              }, 2000
          );
      }
  );
  }

}
